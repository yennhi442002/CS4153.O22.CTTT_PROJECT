import 'package:get/get.dart';

class WelcomeState {
  // Define the properties and methods of your WelcomeState class here
}
