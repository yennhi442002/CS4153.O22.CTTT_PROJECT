import 'package:get/get.dart';

class SignInState {
  // Define the properties and methods of your WelcomeState class here
}
