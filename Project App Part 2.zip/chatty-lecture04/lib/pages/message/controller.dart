import 'package:get/get.dart';
import 'package:chatty/pages/message/state.dart';
import 'package:chatty/common/routes/names.dart';

class MessageController extends GetxController {
  MessageController();
  final title = "Chatty .";
  final state = MessageState();

}
