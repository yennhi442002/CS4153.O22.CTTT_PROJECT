import 'package:flutter/material.dart';

class Iconfont {
    // iconName: share
  static const share = IconData(
    0xe60d,
    fontFamily: 'Iconfont',
    matchTextDirection: true,
  );

  // iconName: fav
  static const fav = IconData(
    0xe60c,
    fontFamily: 'Iconfont',
    matchTextDirection: true,
  );

  // iconName: social-linkedin
  static const sociallinkedin = IconData(
    0xe605,
    fontFamily: 'Iconfont',
    matchTextDirection: true,
  );

  // iconName: social-apple
  static const socialapple = IconData(
    0xe606,
    fontFamily: 'Iconfont',
    matchTextDirection: true,
  );

  // iconName: social-octocat
  static const socialoctocat = IconData(
    0xe607,
    fontFamily: 'Iconfont',
    matchTextDirection: true,
  );

  // iconName: social-reddit
  static const socialreddit = IconData(
    0xe608,
    fontFamily: 'Iconfont',
    matchTextDirection: true,
  );

  // iconName: social-snapchat
  static const socialsnapchat = IconData(
    0xe609,
    fontFamily: 'Iconfont',
    matchTextDirection: true,
  );

  // iconName: social-skype
  static const socialskype = IconData(
    0xe60a,
    fontFamily: 'Iconfont',
    matchTextDirection: true,
  );

  // iconName: social-twitter
  static const socialtwitter = IconData(
    0xe60b,
    fontFamily: 'Iconfont',
    matchTextDirection: true,
  );

  // iconName: me
  static const me = IconData(
    0xe604,
    fontFamily: 'Iconfont',
    matchTextDirection: true,
  );

  // iconName: tag
  static const tag = IconData(
    0xe603,
    fontFamily: 'Iconfont',
    matchTextDirection: true,
  );

  // iconName: grid
  static const grid = IconData(
    0xe602,
    fontFamily: 'Iconfont',
    matchTextDirection: true,
  );
  static const video = IconData(
    0xe04b,
    fontFamily: 'Iconfont',
    matchTextDirection: true,
  );
  static const message = IconData(
    0xe0d8,
    fontFamily: 'Iconfont',
    matchTextDirection: true,
  );

  // iconName: home
  static const home = IconData(
    0xe601,
    fontFamily: 'Iconfont',
    matchTextDirection: true,
  );


}
