// 是否启用代理
const PROXY_ENABLE = false;

/// 代理服务IP
// const PROXY_IP = '192.168.1.105';
const PROXY_IP = '172.16.43.74';

/// 代理服务端口
const PROXY_PORT = 8866;
