// baidu yapi
 const SERVER_API_URL = 'https://chatty.codemain.top/';
 const APPID = "e11666dd3c4346568b67b80823bcca50";

//  yapi
// const SERVER_API_URL = 'http://yapi.ducafecat.tech/mock/11';
