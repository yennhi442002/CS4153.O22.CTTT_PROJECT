const Map<String, String> zh_Hans = {
  'title': '这是标题',
  'login': '登录用户 @name，邮箱账号 @email',
};
