import 'package:get/get.dart';
import 'package:chatty/pages/frame/sign_in/state.dart';
import 'package:chatty/common/routes/names.dart';

class SignInController extends GetxController {
  SignInController();
  final state = SignInState();

}
