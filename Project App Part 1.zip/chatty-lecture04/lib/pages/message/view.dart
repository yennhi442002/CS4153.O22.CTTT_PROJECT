import 'package:chatty/common/values/colors.dart';
import 'package:chatty/pages/message/controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';

class MessagePage extends GetView<MessageController> {
  const MessagePage({Key? key}) : super(key: key); // Fix constructor syntax

  @override
  Widget build(BuildContext context) {
    return Scaffold(

    );
  }
}
