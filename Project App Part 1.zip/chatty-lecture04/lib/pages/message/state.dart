import 'package:get/get.dart';

class MessageState {
  // Define the properties and methods of your WelcomeState class here
}
